import time
import random


def print_pause(message_to_print):
    print(message_to_print)
    time.sleep(2)


def intro():
    print_pause("You are in a boat on an expedition to "
                "find the treasure located on the map.")
    print_pause("The map has some missing parts but has the route set. "
                "However, does not show if there is an island on the way "
                "or any dangerous territory.")
    print_pause("Map only shows the directions, "
                "a narrow passage and the treasure island "
                "after the passage.")
    print_pause("You have 30 fish, some weapons and "
                "a diplomatic letter for negotiations and "
                "safe passage.")


# check validity for user response during game, look for 1 or 2


def valid_input(prompt,
                option1,
                option2):
    while True:
        response = input(prompt)
        if option1 in response:
            break
        elif option2 in response:
            break
        else:
            print_pause("Please provide correct input 1 or 2")
    return response


# check validity of restarting game input, look for yes or no


def restart_input(text, opt1, opt2):
    while True:
        response = input(text).lower()
        if opt1 in response:
            break
        elif opt2 in response:
            break
        else:
            print_pause("Please provide correct input yes or no")
    return response


def restart_game(final):
    if final is False:
        print_pause("You are defeated, GAME OVER")
        resp = restart_input("Would you like to play again? "
                             "(yes/no)\n", "yes", "no")
        if "yes" in resp:
            play_game()
        elif final is True:
            print_pause("OK, goodbye!")
    else:
        print_pause("You are Victorious!")
        resp = restart_input("Would you like to "
                             "play again? (yes/no)\n", "yes", "no")
        if "yes" in resp:
            play_game()
        else:
            print_pause("OK, goodbye!")


def sail(items, final):
    print_pause("An island appeares on the Horizon.")
    print_pause("What action do you want to take?")
    action = valid_input("1. Go to the island\n"
                         "2. Pass island and "
                         "continue your journey\n", "1", "2")
    if action == '1':
        time.sleep(2)
        dock_island(items, final)
    else:
        time.sleep(2)
        continue_journey(items, final)


def dock_island(items, final):
    print_pause("The ship docks to the island.")
    print_pause("The governer/leader of the island approaches to you.")
    print_pause("What actions do you want to take?")
    island_action = valid_input("1. Ask for help using the diplomatic letter\n"
                                "2. Threaten to raid the island\n", "1", "2")
    if island_action == '1':
        stay_on_island(items, final)
    else:
        threaten(items, final)


def stay_on_island(items, final):
    items[0] += 15
    items.append('Fighters')
    print_pause("The island leader offers 15 fish "
                "(Total of 30 + 15 = 45 fish in stock), "
                "more advanced weapons and trained fighters for "
                "a fair share of the treasure.")
    print_pause("What actions do you want to take?")
    island_action2 = valid_input("1. Look for additional support on island\n"
                                 "2. Continue journey\n", "1", "2")
    if island_action2 == '1':
        support(items, final)
    else:
        continue_journey(items, final)


def threaten(items, final):  # Defeat
    print_pause("You do not have enough fire power and fighters!"
                "The islanders overpower you!")
    restart_game(final)


def support(items, final):
    # 1 stands sea monster expert, 2 no additional support.
    rand1 = random.randint(1, 3)
    if rand1 == 1:
        print_pause("One of your crew members encounter a "
                    "sea monster expert while taking a tour "
                    "around town center on the island.\n"
                    "As the captain you explain your "
                    "journey to the expert and "
                    "ask help from the expert.")
        print_pause("Without hesitation the sea monster "
                    "expert accepts your proposal, "
                    "joins your crew and provides special canons "
                    "designed by himself.")
        items.append("Monster Expert")
        continue_journey(items, final)
    else:
        print_pause("No one encountered anyone to support your voyage, "
                    "the ship sets sail towards the objective")
        continue_journey(items, final)


def continue_journey(items, final):
    print_pause("You have fed the crew, used 15 fish from stock.")
    items[0] -= 15
    print_pause("The crew set sail towards the objective.")
    narrow_passage(items, final)


# 1 stands for pirate ship,
# 2 stands for sea monster,
# 3 stands for open passage.


def narrow_passage(items, final):
    rand2 = random.randint(1, 4)
    if rand2 == 1:
        pirate_ship(items, final)
    elif rand2 == 2:
        sea_monster(items, final)
    else:
        open_passage(final)


def pirate_ship(items, final):
    print_pause("Your ship approaches towards the narrow passage "
                "and the crew spotted a pirate ship at the entrance.")
    print_pause("What action do you want to take?")
    action = valid_input("1. Attack the pirates\n"
                         "2. Take the long way around\n", "1", "2")
    if action == '1':
        time.sleep(2)
        attack_pirates(items, final)
    else:
        time.sleep(2)
        long_way(items, final)


def sea_monster(items, final):
    print_pause("Your ship approaches towards the narrow passage "
                "and the crew spotted a sea monster at the entrance.")
    print_pause("What action do you want to take?")
    action = valid_input("1. Attack the monster\n"
                         "2. Take the long way around\n", "1", "2")
    if action == '1':
        time.sleep(2)
        attack_monster(items, final)
    else:
        time.sleep(2)
        long_way(items, final)


def open_passage(final):
    print_pause("Your ship approaches towards "
                "the narrow passage and the path is clear.")
    print_pause("What a lucky day for the captain and the crew!")
    treasure_island(final)


def attack_monster(items, final):
    if "Monster Expert" in items:
        print_pause("You defeated the monster "
                    "with the help of the monster expert and "
                    "special canons! "
                    "The ship proceed towards the treasure island.\n")
        treasure_island(final)
    else:
        print_pause("The crew is extremely scared. "
                    "They lack special canons and lacks knowledge about "
                    "sea monsters and specific weapons to fight back.\n"
                    "The monster destroyes the ship!\n")
        restart_game(final)


def attack_pirates(items, final):
    if "Fighters" in items:
        print_pause("You defeated the pirates with the advanced weapons "
                    "and trained fighters! "
                    "The ship proceed towards the treasure island.\n")
        treasure_island(final)
    else:
        print_pause("You do not have enough fire power and fighters. "
                    "The pirates overpower you!\n")
        restart_game(final)


def long_way(items, final):
    print_pause("Your ship proceeds with the long way around. "
                "However, the map does not show any path after this point.")
    print_pause("You have to navigate the path by your own.")
    while True:
        if items[0] == 0:
            print_pause("You are out of food and supply")
            restart_game(final)
            break
        else:
            print_pause("While ship navigates around the unknown areas, "
                        "the crew is fed and 15 fish is used each time.")
            items[0] -= 15


def treasure_island(final):

    print_pause("Ship docks the treasure island shown on the map."
                " You and the crew investigate the island.")
    print_pause("After couple of hours you have located the treasure!")
    final = True
    restart_game(final)


def play_game():
    items = [30]
    final = False
    intro()
    sail(items, final)


play_game()
